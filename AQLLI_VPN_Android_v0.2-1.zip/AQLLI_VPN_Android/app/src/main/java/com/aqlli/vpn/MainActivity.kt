package com.aqlli.vpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import org.json.JSONObject

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 15, 25)
    private val panel = Color.rgb(20, 30, 43)
    private val green = Color.rgb(76, 235, 154)
    private var selected = "AUTO • Smart server"
    private var importedServers: List<String> = emptyList()
    private lateinit var status: TextView
    private lateinit var serverContainer: LinearLayout

    private val defaultServers = listOf(
        "AUTO • Smart server", "Netherlands", "Germany", "France", "Ireland",
        "Sweden", "Romania", "Estonia", "Poland", "USA", "Finland", "Italy"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 34, 24, 28)
        }
        scroll.addView(page)

        page.addView(TextView(this).apply {
            text = "⚡ AQLLI VPN"
            textSize = 29f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }, matchWrap())

        page.addView(TextView(this).apply {
            text = "FAST • SMART • SECURE"
            textSize = 12f
            letterSpacing = 0.18f
            setTextColor(green)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 26)
        }, matchWrap())

        status = TextView(this).apply {
            text = "DISCONNECTED"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 12)
        }
        page.addView(status, matchWrap())

        page.addView(Button(this).apply {
            text = "CONNECT"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(4, 20, 15))
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(green))
            setOnClickListener { requestVpnPermission() }
        }, LinearLayout.LayoutParams(-1, 64).apply { setMargins(8, 8, 8, 24) })

        page.addView(sectionTitle("SERVER LOCATION"), matchWrap())
        serverContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(serverContainer, matchWrap())
        renderServers()

        page.addView(Button(this).apply {
            text = "IMPORT CONFIGURATION (.JSON)"
            setOnClickListener { openConfigPicker() }
        }, LinearLayout.LayoutParams(-1, 54).apply { setMargins(0, 20, 0, 8) })

        page.addView(TextView(this).apply {
            text = "Imported server entries are read from the JSON outbounds. A compatible VPN core is still required for live connections, ping and automatic failover."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(8, 16, 8, 8)
        }, matchWrap())

        setContentView(scroll)
    }

    private fun renderServers() {
        serverContainer.removeAllViews()
        val names = if (importedServers.isNotEmpty()) listOf("AUTO • Smart server") + importedServers else defaultServers
        names.forEach { name ->
            serverContainer.addView(TextView(this).apply {
                text = (if (name.startsWith("AUTO")) "⚡  " else "🌐  ") + name + "     ›"
                textSize = 15f
                setTextColor(if (name == selected) green else Color.WHITE)
                setPadding(18, 17, 18, 17)
                setBackgroundColor(panel)
                setOnClickListener {
                    selected = name
                    renderServers()
                }
            }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 5, 0, 5) })
        }
    }

    private fun requestVpnPermission() {
        val intent = VpnService.prepare(this)
        if (intent != null) startActivityForResult(intent, 100)
        else onActivityResult(100, RESULT_OK, null)
        Toast.makeText(this, "Permission flow is ready; VPN engine integration is still required.", Toast.LENGTH_LONG).show()
    }

    private fun openConfigPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
        }
        startActivityForResult(intent, 200)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            200 -> {
                val uri = data?.data ?: return
                try {
                    contentResolver.openInputStream(uri)?.bufferedReader()?.use { reader ->
                        val json = JSONObject(reader.readText())
                        val outbounds = json.optJSONArray("outbounds") ?: error("No outbounds array")
                        val parsed = mutableListOf<String>()
                        for (i in 0 until outbounds.length()) {
                            val outbound = outbounds.optJSONObject(i) ?: continue
                            val protocol = outbound.optString("protocol")
                            if (protocol !in setOf("vless", "vmess", "trojan", "shadowsocks")) continue
                            val settings = outbound.optJSONObject("settings")
                            val vnext = settings?.optJSONArray("vnext")
                            val server = vnext?.optJSONObject(0)?.optString("address")
                            val label = outbound.optString("tag").ifBlank { protocol.uppercase() }
                            if (!server.isNullOrBlank()) parsed.add("$label • $server")
                            else parsed.add("$label • ${protocol.uppercase()}")
                        }
                        importedServers = parsed.distinct()
                        selected = "AUTO • Smart server"
                        renderServers()
                        Toast.makeText(this, "Imported ${importedServers.size} server entries", Toast.LENGTH_LONG).show()
                    } ?: error("Cannot open selected file")
                } catch (e: Exception) {
                    Toast.makeText(this, "Config import failed: ${e.message ?: "invalid JSON"}", Toast.LENGTH_LONG).show()
                }
            }
            100 -> status.text = "VPN PERMISSION GRANTED • ENGINE NOT CONNECTED"
        }
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(green)
        setPadding(4, 10, 4, 10)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
}
