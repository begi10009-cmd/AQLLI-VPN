package com.aqlli.vpn

import android.net.VpnService

/**
 * Android VPN service declaration.
 * A real tunnel is NOT implemented yet. Integrate a compatible V2Ray/Xray core
 * and its tun2socks/VpnService bridge before enabling production connections.
 */
class AqlliVpnService : VpnService()
