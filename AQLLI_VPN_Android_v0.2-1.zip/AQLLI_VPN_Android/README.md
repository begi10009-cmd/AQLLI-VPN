# AQLLI VPN — Android starter project (v0.2)

## Added in this revision
- Classic server list UI
- JSON file picker for configuration import
- Basic parsing of `outbounds` entries for VLESS, VMess, Trojan and Shadowsocks
- Displays imported outbound tags and server addresses

## Important: still not a working VPN
The app currently does not start a proxy tunnel. The Android VPN permission flow and
service declaration are scaffolding only. No Xray/V2Ray core or TUN bridge is bundled.
Live VPN connection, ping measurement, speed measurement, Smart Auto health checks,
and automatic failover are not implemented.

The supplied sample uses several core/version-specific options (including XHTTP
extras, `finalmask`, and observatory/balancer settings). Validate it against the
chosen compatible core before shipping.

## Build
Open this folder in Android Studio, sync Gradle, and build the debug APK. A local
Android SDK and compatible JDK are required.
